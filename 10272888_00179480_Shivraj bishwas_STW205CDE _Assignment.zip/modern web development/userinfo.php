<?php
$con= mysqli_connect('localhost','root','');
if($con){
	echo "Connection successful";

}
else{
	echo "Not Connected";
}

mysqli_select_db($con, 'userinfo data');
$User=$_POST['user'];
$Email id=$_POST['Email id'];
$Address=$_POST['Address'];
$Mobile=$_POST['Mobile'];
$Comments=$_POST['Comments'];

$query="insert into userinfo data(Username, Email Id, Address, Mobiles, Comments)
values ('$user','$Email Id','$Address','$Mobile','$Comments')";

mysqli_query($con,$query);
header ('location: index.html')




?>